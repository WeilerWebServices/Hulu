#!/usr/bin/env python2.7
# coding=utf-8

from restfulgit import app

app.debug = True
app.run(host="0.0.0.0")
